;;; ---------------------------------------------------------------------------
;;; Simple object system with inheritance
(define true #t)
(define false #f)

(define (ask object message . args)  ;; See page 104 to explain "."
  (let ((method (get-method object message)))
    (if (method? method)
	(apply method (cons object args))
	(error "No method" message (cadr method)))))

(define (get-method object message)
  (object message))

(define (no-method name)
  (list 'no-method name))

(define (method? x)
  (not (no-method? x)))

(define (no-method? x)
  (if (pair? x)
      (eq? (car x) 'no-method)
      false))

;;; ----------------------------------------------------------------------------
;;; Persons, places, and things will all be kinds of named objects

(define (make-named-object name)
  (lambda (message) 
    (cond ((eq? message 'name) (lambda (self) name))
	  (else (no-method name)))))

;;; Persons and things are mobile since their places can change

(define (make-mobile-object name location)
  (let ((named-obj (make-named-object name)))
    (lambda (message)
      (cond ((eq? message 'place)    (lambda (self) location))
	    ((eq? message 'install)
	     (lambda (self)
	       (ask location 'add-thing self)))	; Synchonize thing and place
	    ;; Following method should never be called by the user...
	    ;;  it is a system-internal method.
	    ;; See CHANGE-PLACE instead
	    ((eq? message 'set-place)
	     (lambda (self new-place)
	       (set! location new-place)
	       'place-set))
	    (else (get-method named-obj message))))))

(define (make&install-mobile-object name place)
  (let ((mobile-obj (make-mobile-object name place)))
    (ask mobile-obj 'install)
    mobile-obj))

;;; A thing is something that can be owned

(define (make-thing name birthplace)
  (let ((owner     'nobody)
	(mobile-obj (make-mobile-object name birthplace)))
    (lambda (message)
      (cond ((eq? message 'owner)    (lambda (self) owner))
	    ((eq? message 'ownable?) (lambda (self) true))
	    ((eq? message 'owned?)
	     (lambda (self)
	       (not (eq? owner 'nobody))))
	    ;; Following method should never be called by the user...
	    ;;  it is a system-internal method.
	    ;; See TAKE and LOSE instead.
	    ((eq? message 'set-owner)
	     (lambda (self new-owner)
	       (set! owner new-owner)
	       'owner-set))
	    (else (get-method mobile-obj message))))))

(define (make&install-thing name birthplace)	
  (let ((thing  (make-thing name birthplace)))
    (ask thing 'install)
    thing))

;;; Implementation of places

(define (make-place name)
  (let ((neighbor-map '())		
	(things       '())
	(named-obj (make-named-object name)))
    (lambda (message)
      (cond ((eq? message 'things) (lambda (self) things))
	    ((eq? message 'neighbors)
	     (lambda (self) (map cdr neighbor-map)))
	    ((eq? message 'exits)
	     (lambda (self) (map car neighbor-map)))
	    ((eq? message 'neighbor-towards)
	     (lambda (self direction)
	       (let ((places (assq direction neighbor-map)))
		 (if places
		     (cdr places)
		     false))))
            ((eq? message 'add-neighbor)
             (lambda (self direction new-neighbor)
               (cond ((assq direction neighbor-map)
                      (display-message (list "Direction already assigned"
					      direction name))
		      false)
                     (else
                      (set! neighbor-map
                            (cons (cons direction new-neighbor) neighbor-map))
		      true))))
	    ((eq? message 'accept-person?)
	     (lambda (self person)
	       true))
 
	    ;; Following two methods should never be called by the user...
	    ;;  they are system-internal methods. See CHANGE-PLACE instead.
            ((eq? message 'add-thing)
             (lambda (self new-thing)
               (cond ((memq new-thing things)
                      (display-message (list (ask new-thing 'name)
					     "is already at" name))
		      false)
                     (else (set! things (cons new-thing things))
			   true))))
            ((eq? message 'del-thing)
             (lambda (self thing)
               (cond ((not (memq thing things))
                      (display-message (list (ask thing 'name)
					     "is not at" name))
		      false)
                     (else (set! things (delq thing things))	;; DELQ defined
			   true))))                             ;; below

            (else (get-method named-obj message))))))

;;; Implementation of Card Locked Places

(define (make-card-locked-place name)
  (let ((place (make-place name)))
    (lambda (message)
      (cond ((eq? message 'accept-person?)
               (lambda (self person) 
                 (if (carrying-card? (ask person 'possessions))
                        (begin (display-message (list "Access Granted")) true)
                        (begin (display-message (list "Access Denied!")) false))))
            (else (get-method place message))))))

(define (carrying-card? possessions)
  (cond ((null? possessions) false)
        ((is-a (car possessions) 'sd-card?) true)
        (else (carrying-card? (cdr possessions)))))

;Implementation of Student Residences
(define (make-student-residence name)
  (let ((place (make-place name))
	(card-list '()))
    (lambda (message)
      (cond ((eq? message 'card-list)
	     (lambda (self) card-list))
	    ((eq? message 'accept-person?)
	     (lambda (self person)
	       (if (carrying-card? (ask person 'possessions))
                  (if (memq (car (map (lambda (x) (ask x 'id))
                                      (filter (lambda (x) (is-a x 'sd-card?)) (ask person 'possessions))))
                            card-list)
                      (begin (display-message (list "Access Granted")) true)
                      (begin (display-message (list "Access Denied")) false))
                  (begin (display-message (list "Access Denied")) false))))
	    ((eq? message 'register-card)
	     (lambda (self card)
	       (if (eq? self (ask card 'place))
				  (set! card-list (append (list (ask card 'id)) card-list))
				  (display "Failed to Register card; invalid birthplace"))))
	    (else (get-method place message))))))



;;; ----------------------------------------------------------------------------
;;; Implementation of people

(define (make-person name birthplace threshold)
  (let ((possessions '())
	(mobile-obj  (make-mobile-object name birthplace)))
    (lambda (message)
      (cond ((eq? message 'person?)     (lambda (self) true))
	    ((eq? message 'possessions) (lambda (self) possessions))
	    ((eq? message 'list-possessions)
	     (lambda (self)
	       (ask self 'say
		    (cons "I have"
			  (if (null? possessions)
			      '("nothing")
			      (map (lambda (p) (ask p 'name))
				      possessions))))
	       possessions))
	    ((eq? message 'say)
	     (lambda (self list-of-stuff)
	       (display-message
		 (append (list "At" (ask (ask self 'place) 'name)
			       ":"  name "says --")
			 (if (null? list-of-stuff)
			     '("Oh, nevermind.")
			     list-of-stuff)))
	       'said))
	    ((eq? message 'have-fit)
	     (lambda (self)
	       (ask self 'say '("Yaaaah! I am upset!"))
	       'I-feel-better-now))
	    ((eq? message 'look-around)
	     (lambda (self)
	       (let ((other-things
		       (map (lambda (thing) (ask thing 'name))
                               (delq self                       ;; DELQ
                                     (ask (ask self 'place)     ;; defined
                                          'things)))))          ;; below
                 (ask self 'say (cons "I see" (if (null? other-things)
						  '("nothing")
						  other-things)))
		 other-things)))

	    ((eq? message 'take)
	     (lambda (self thing)
	       (cond ((memq thing possessions)
		      (ask self 'say
			   (list "I already have" (ask thing 'name)))
		      true)
		     ((and (let ((things-at-place (ask (ask self 'place) 'things)))
			     (memq thing things-at-place))
			   (is-a thing 'ownable?))
		      (if (ask thing 'owned?)
			  (let ((owner (ask thing 'owner)))
			    (ask owner 'lose thing)
			    (ask owner 'have-fit))
			  'unowned)

		      (ask thing 'set-owner self)
		      (set! possessions (cons thing possessions))
		      (ask self 'say
			   (list "I take" (ask thing 'name)))
		      true)
		     (else
		      (display-message
		       (list "You cannot take" (ask thing 'name)))
		      false))))
            ((eq? message 'give)
             (lambda (self thing person)
               (cond ((and (eq? 'late-homework (ask thing 'name)) 
                           (eq? 'keith (ask person 'name)))
                       (ask keith 'say (list "This is the last time I'm accepting late homework from you!"))))
               
               (cond ((eq? self (ask thing 'owner))
		      (set! possessions (delq thing possessions))               
		      (ask self 'say (list "I give" (ask thing 'name)))
                      (ask thing 'set-owner 'nobody)
                      (ask person 'take thing)
		      true)
		     (else
		      (display-message (list name "does not own"
					     (ask thing 'name)))
		      false))))
              
               
               
	    ((eq? message 'lose)
	     (lambda (self thing)
	       (cond ((eq? self (ask thing 'owner))
		      (set! possessions (delq thing possessions)) ;; DELQ
		      (ask thing 'set-owner 'nobody)              ;; defined
		      (ask self 'say                              ;; below
			   (list "I lose" (ask thing 'name)))
		      true)
		     (else
		      (display-message (list name "does not own"
					     (ask thing 'name)))
		      false))))
	    ((eq? message 'move)
	     (lambda (self)
	       (cond ((= (random threshold) 0)
		      (ask self 'act)
		      true)
		     (else true))))
	    ((eq? message 'act)
	     (lambda (self)
	       (let ((new-place (random-neighbor (ask self 'place))))
		 (if new-place
		     (ask self 'move-to new-place)
		     false))))		; All dressed up and no place to go

	    ((eq? message 'move-to)
	     (lambda (self new-place)
	       (let ((old-place (ask self 'place)))
		 (cond ((eq? new-place old-place)
			(display-message (list name "is already at"
					       (ask new-place 'name)))
			false)
		       ((ask new-place 'accept-person? self)
			(change-place self new-place)
			(for-each (lambda (p) (change-place p new-place))
				  possessions)
			(display-message
			  (list name "moves from" (ask old-place 'name)
				     "to"         (ask new-place 'name)))
			(greet-people self (other-people-at-place self new-place))
			true)
		       (else
			(display-message (list name "can't move to"
					       (ask new-place 'name))))))))
	    ((eq? message 'go)
	     (lambda (self direction)
	       (let ((old-place (ask self 'place)))
		 (let ((new-place (ask old-place 'neighbor-towards direction)))
		   (cond (new-place
			  (ask self 'move-to new-place))
			 (else
			  (display-message (list "You cannot go" direction
						 "from" (ask old-place 'name)))
			  false))))))
	    ((eq? message 'install)
	     (lambda (self)
	       (add-to-clock-list self)
	       ((get-method mobile-obj 'install) self)))
	    (else (get-method mobile-obj message))))))
  
(define (make&install-person name birthplace threshold)
  (let ((person (make-person name birthplace threshold)))
    (ask person 'install)
    person))

;;; A troll is a kind of person (but not a kind person!)

(define (make-troll name birthplace threshold)
  (let ((person (make-person name birthplace threshold)))
    (lambda (message)
      (cond ((eq? message 'act)
	     (lambda (self)
	       (let ((others (other-people-at-place self (ask self 'place))))
		 (if (not (null? others))
		     (ask self 'eat-person (pick-random others))
		     ((get-method person 'act) self)))))
	    ((eq? message 'eat-person)
	     (lambda (self person)
	       (ask self 'say
		    (list "Growl.... I'm going to eat you,"
			  (ask person 'name)))
	       (go-to-heaven person)
	       (ask self 'say
		    (list "Chomp chomp." (ask person 'name)
			  "tastes yummy!"))
	       '*burp*))
	    (else (get-method person message))))))

(define (make&install-troll name birthplace threshold)
  (let ((troll  (make-troll name birthplace threshold)))
    (ask troll 'install)
    troll))

(define (make-ogre name birthplace threshold id)
  (let ((person (make-person name birthplace threshold)))
    (lambda (message)
      (cond ((eq? message 'id)
             (lambda (self) id))
            ((eq? message 'act)
	     (lambda (self)
	       (let ((cardholders (filter (lambda (x) (carrying-card? (ask x 'possessions))) 
                                           (other-people-at-place self (ask self 'place)))))
		 (if (crook-in-room? self cardholders)
		     (ask self 'eat-person (crook-in-room? self cardholders))
		     ((get-method person 'act) self)))))
            ((eq? message 'eat-person)
	     (lambda (self person)
	       (ask self 'say
		    (list "Here's what happens when you steal cards,"
			  (ask person 'name)))
               (go-to-heaven person)
	       (ask self 'say
		    (list "Chomp chomp." (ask person 'name)
			  "tastes yummy!"))
	       '*burp*))
            (else (get-method person message))))))


                 

(define (make&install-ogre id)
  (let ((ogre  (make-ogre 'Igor dungeon 1 id)))
    (ask ogre 'install)
    ogre))

(define (crook-in-room? self cardholders)
  (cond ((null? cardholders) false)
        ((eq? (ask self 'id)
              (car (map (lambda (x) (ask x 'id))
                        (filter (lambda (x) (is-a x 'sd-card?)) 
                                (ask (car cardholders) 'possessions)))))
         (car cardholders))
        (else (crook-in-room? self (cdr cardholders)))))

(define (report-stolen-card id)
  (define igor (make&install-ogre id))
  (ask igor 'say '(Arrr...me find crook!)))
  
      
      
(define (go-to-heaven person)
  (for-each (lambda (item) (ask person 'lose item))
	    (ask person 'possessions))
  (ask person 'say
       '("
                   Dulce et decorum est 
                   pro computatore mori!"
	 ))
  (ask person 'move-to heaven)
  (remove-from-clock-list person)
  'game-over-for-you-dude)

(define heaven (make-place 'heaven))		; The point of no return

;;; --------------------------------------------------------------------------
;;; Clock routines

(define *clock-list* '())
(define *the-time* 0)

(define (initialize-clock-list)
  (set! *clock-list* '())
  'initialized)

(define (add-to-clock-list person)
  (set! *clock-list* (cons person *clock-list*))
  'added)

(define (remove-from-clock-list person)
  (set! *clock-list* (delq person *clock-list*))  ;; DELQ defined below
  'removed)

(define (clock)
  (newline)
  (display "---Tick---")
  (set! *the-time* (+ *the-time* 1))
  (for-each (lambda (person) (ask person 'move))
	    *clock-list*)
  'tick-tock)
	     

(define (current-time)
  *the-time*)

(define (run-clock n)
  (cond ((zero? n) 'done)
	(else (clock)
	      (run-clock (- n 1)))))

;;; --------------------------------------------------------------------------
;;; Miscellaneous procedures

(define (is-a object property)
  (let ((method (get-method object property)))
    (if (method? method)
	(ask object property)
	false)))

(define (change-place mobile-object new-place)	; Since this bridges the gap
  (let ((old-place (ask mobile-object 'place))) ; between MOBILE-OBJECT and
    (ask mobile-object 'set-place new-place)	; PLACE, it is best it not
    (ask old-place 'del-thing mobile-object))	; be internal to either one.
  (ask new-place 'add-thing mobile-object)
  'place-changed)

(define (other-people-at-place person place)
  (filter (lambda (object)
	    (if (not (eq? object person))
		(is-a object 'person?)
		false))
	  (ask place 'things)))

(define (greet-people person people)
  (if (not (null? people))
      (ask person 'say
	   (cons "Hi"
		 (map (lambda (p) (ask p 'name))
			 people)))
      'sure-is-lonely-in-here))

(define (display-message list-of-stuff)
  (newline)
  (for-each (lambda (s) (display s) (display " "))
	    list-of-stuff)
  'message-displayed)

(define (random-neighbor place)
  (pick-random (ask place 'neighbors)))

(define (filter predicate lst)
  (cond ((null? lst) '())
	((predicate (car lst))
	 (cons (car lst) (filter predicate (cdr lst))))
	(else (filter predicate (cdr lst)))))

(define (pick-random lst)
  (if (null? lst)
      false
      (list-ref lst (random (length lst)))))  ;; See manual for LIST-REF

(define (delq item lst)
  (cond ((null? lst) '())
	((eq? item (car lst)) (delq item (cdr lst)))
	(else (cons (car lst) (delq item (cdr lst))))))

;;; -------------------------------------------------------------------
;;; Other interesting procedures

(define (make&install-sd-card name birthplace id)
  (let ((card (make-sd-card name birthplace id)))
    (ask card 'install)
    card))

(define (make-sd-card name birthplace idnumber)
  (let ((id idnumber)
        (thing (make-thing name birthplace)))
    (lambda (message)
      (cond ((eq? message 'sd-card?) (lambda (self) true))
            ((eq? message 'id) (lambda (self) id))
            (else (get-method thing message))))))

(define (copy-sd-card card)
  (let ((name   (symbol-append 'copy-of- (ask card 'name)))
	(place  (ask card 'place))
	(id     (ask card 'id)))
    (make&install-sd-card name place id)))

(define  (symbol-append sym1 sym2)
  (let* ((str1 (symbol->string sym1))
	 (str2 (symbol->string sym2)))
    (string->symbol (string-append str1 str2))))
    


;;;============================================================================
;;; You can extend this file to make more stuff part of your world.
;;;============================================================================

;;;============================================================================
;;; *CAVEAT* To avoid retyping long strings of commands,   
;;;          you should create little scripts at the  
;;;          end of this file to make the game evolve as you work through it.  
;;;          [See the bottom of this file for an example.]                     
;;;============================================================================

(initialize-clock-list)

;; Here we define the places in our world...
;;------------------------------------------

(define Greenhouse     (make-place 'Greenhouse))
(define dungeon        (make-place 'dungeon))
(define Smith-Hall     (make-place 'Smith-Hall))
(define computer-lab   (make-place 'computer-lab))
(define Trabant-Center (make-place 'Trabant-Center))
(define keith-office   (make-card-locked-place 'keith-office))
(define errol-office   (make-card-locked-place 'errol-office))
(define dormitory      (make-student-residence 'dormitory))
(define Towers         (make-student-residence 'towers))

(define heaven       (make-place 'heaven))	; The point of no return

;; One-way paths connect individual places in the world.
;;------------------------------------------------------

(define (can-go from direction to)
  (ask from 'add-neighbor direction to))

(define (can-go-both-ways from direction reverse-direction to)
  (can-go from direction to)
  (can-go to reverse-direction from))

(can-go-both-ways Smith-Hall 'up    'down  computer-lab)
(can-go-both-ways Smith-Hall 'north 'south Trabant-Center)
(can-go-both-ways Smith-Hall 'east  'west  Greenhouse)
(can-go-both-ways Smith-Hall 'west  'east  errol-office)
(can-go-both-ways Greenhouse 'up    'down  keith-office)
(can-go-both-ways dormitory  'west  'east  Trabant-Center)
(can-go-both-ways Towers     'south 'north Trabant-Center)

(can-go dungeon      'up    Trabant-Center)

;; The important critters in our world...
;;---------------------------------------

(define errol   (make&install-person 'errol   errol-office 3))
(define keith   (make&install-person 'keith   keith-office 2))

(define grendel (make&install-troll  'grendel dungeon      4))

(define keith-card
  (make&install-sd-card 'keith-card keith-office '888-12-3456))
(define errol-card
  (make&install-sd-card 'errol-card errol-office '888-98-7654))
(define jamie-card
  (make&install-sd-card 'jamie-card dormitory '123-45-6789))


;; The beginning of an ever-expanding game script
;;------------------------------------------------

(define (play-game)
  (ask keith 'take keith-card)
  (ask keith 'go 'down)
  (ask keith 'go 'west)
  )

;; ...now whenever you re-load this file, you can bring things up to
;; date by invoking PLAY-GAME.


(define flip
  (let ((num 0))
    (lambda ()
      (begin (if (= num 0)
               (set! num 1)
               (set! num 0))
              num))))

(define ice-cream (make-thing 'ice-cream dormitory))

(ask ice-cream 'set-owner keith)

(define rodney (make-student-residence 'rodney))
(define Jamie (make&install-person 'Jamie towers 100))

(define late-homework (make&install-thing 'late-homework dormitory))

(define hell (make-card-locked-place 'hell))




 (define towers-card (make&install-sd-card 'towers-card towers 3))
 (define dormitory-card (make&install-sd-card 'dormitory-card dormitory 12))



(ask towers 'register-card towers-card)


(ask jamie 'take towers-card)

(ask jamie 'move-to trabant-center)











