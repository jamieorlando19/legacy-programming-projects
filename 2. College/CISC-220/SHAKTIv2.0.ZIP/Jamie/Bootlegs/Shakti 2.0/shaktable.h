//Jamie Orlando
//Class Header File for type "shaktable"

#ifndef SHAKTABLE_H

#include<iostream>
#include<list>
#include<string.h>
#include<math.h>
using namespace std;

//String of 32 Characters (for <list>)
typedef struct Cstring
{ char ptr[32]; }str;

//Field Name
struct fname
{
   str name;                             //Field Name
   int flag;                             //0=INT, 1=CHAR, 2=FLOAT
};
  
//Field Entry
struct fieldentry
{
   int int_entry;                        //Integer Entry
   str char_entry;                       //Character Entry
   float float_entry;                    //Float Entry
   int filled;                           //1=FILLED, 0=NOT
   fieldentry *collision, *bptr, *fptr;  //Collision, Back & Front Pointers
   fieldentry();                         //Constructor
};

//Binary Node
struct binnode
{
   fieldentry *field_ptr;                //Points To Fieldentry
   binnode *left, *right, *repeat;       //Left, Right & Repeat (Collision) Pointers
   binnode();                            //Constructor
};

const int max_column = 101;

class shaktable
{
   public:
     shaktable(str &, list<fname> &);                 //Constructor 
     str get_name();                                  //Table Name Accessor
     list<fname> get_fields();                        //Fieldnames Accessor
     void insert(list<fieldentry> &);                 //Insert
     void print_all();                                //Print all
     void print_where(str &, fieldentry &);           //Print Where
     void join_all(shaktable &);                      //Join all
     void join_where(shaktable &, str &, str &, str &, fieldentry &);// 
                                                      //Join where/////
     void order_by(str &);                            //Order By
   private:
     void recursive_print_all(binnode *);
     void recursive_join_all(binnode *, binnode *, list<fname> &);        
     void recursive_join_all2(binnode *, fieldentry &, list<fname> &);
     void recursive_order_by(binnode *, binnode *&, fieldentry *, int &, int, int, int);
     void print_row(fieldentry &, list<fname> &);             //Prints row
     void tree_insert(binnode *&, fieldentry *&, int, int &); //Tree Insert
     int hash_convert(fieldentry &, int);                     //Hash Converter

     //DATA MEMBERS

     str table_name;                                  //Table Name
     list<fname> fieldnames;                          //Field Names (& flags)
     fieldentry **table_data;                         //Table Data
     binnode *table_index;                            //Table Index
};

#define SHAKTABLE_H
#endif
